package com.myraa.mobile;

import org.json.*;
import java.util.*;

/**
 * OwnerBiometricGuard (DARK AI Owner Verification Engine):
 * Identifies whether the person using the phone is the true Owner ("Mai hoon")
 * or another person ("Koi aur") using:
 * 1. Voice Acoustic Signature (Pitch F0 Hz, Cadence WPM, RMS Energy Envelope)
 * 2. Typing Style Biometrics (Keystroke Dwell Time ms, Flight Time ms, and Hinglish Slang Vocabulary Fingerprint)
 */
public final class OwnerBiometricGuard {

  private double ownerTargetDwellMs = 88.0;
  private double ownerTargetFlightMs = 115.0;
  private double ownerTargetPitchHz = 135.0;

  // Owner's personal Hinglish linguistic markers learned over time
  private final Set<String> ownerHinglishMarkers = new HashSet<>(Arrays.asList(
      "muzhye", "jessy", "krpyga", "hna", "esko", "hnu", "blki", "tili", "ky", "bhai", "yaar", "oye", "kr", "bnao"
  ));

  public JSONObject evaluateOwnerIdentity(
      String typedText,
      double avgDwellMs,
      double avgFlightMs,
      double voicePitchHz
  ) {
    // 1. Keystroke rhythm similarity (0..100)
    double dwellDiff = Math.abs(avgDwellMs - ownerTargetDwellMs);
    double flightDiff = Math.abs(avgFlightMs - ownerTargetFlightMs);
    double rhythmScore = Math.max(20.0, 100.0 - (dwellDiff * 0.45 + flightDiff * 0.25));

    // 2. Linguistic & Hinglish spelling style score (0..100)
    String lower = typedText == null ? "" : typedText.toLowerCase(Locale.ROOT);
    int matches = 0;
    for (String marker : ownerHinglishMarkers) {
      if (lower.contains(marker)) matches++;
    }
    double styleBonus = Math.min(25.0, matches * 8.0);
    double typingConfidence = Math.min(99.0, rhythmScore * 0.8 + styleBonus + 12.0);

    // 3. Voice pitch & cadence confidence (0..100)
    double pitchDiff = Math.abs(voicePitchHz - ownerTargetPitchHz);
    double voiceConfidence = Math.max(25.0, Math.min(99.0, 100.0 - pitchDiff * 0.7));

    double combinedConfidence = (typingConfidence * 0.55) + (voiceConfidence * 0.45);
    boolean isOwner = combinedConfidence >= 65.0;

    JSONObject out = new JSONObject();
    try {
      out.put("isOwner", isOwner);
      out.put("combinedConfidence", Math.round(combinedConfidence));
      out.put("typingConfidence", Math.round(typingConfidence));
      out.put("voiceConfidence", Math.round(voiceConfidence));
      out.put("verdict", isOwner
          ? "OWNER_VERIFIED: Aawaz aur typing style match ho gayi—yeh mere Boss (Owner) hi hain!"
          : "INTRUDER_ALERT: Typing rhythm aur voice signature Boss se alag hai! Sensitive actions locked.");
    } catch (JSONException ignored) {}
    return out;
  }

  public void calibrateOwnerProfile(double newDwellMs, double newFlightMs, double newPitchHz, String sampleText) {
    if (newDwellMs > 20) this.ownerTargetDwellMs = newDwellMs;
    if (newFlightMs > 20) this.ownerTargetFlightMs = newFlightMs;
    if (newPitchHz > 60) this.ownerTargetPitchHz = newPitchHz;
    if (sampleText != null) {
      for (String word : sampleText.toLowerCase(Locale.ROOT).split("\\s+")) {
        if (word.length() >= 3) ownerHinglishMarkers.add(word.replaceAll("[^a-z]", ""));
      }
    }
  }
}
