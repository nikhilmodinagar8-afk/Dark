package com.myraa.mobile;

import org.json.*;
import javax.net.ssl.HttpsURLConnection;
import java.io.*;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public final class MultiApiFallbackProvider {
  public static String generateWithAutoFallback(
      String geminiKey,
      String groqKey,
      String openRouterKey,
      String systemPrompt,
      String userMessage
  ) throws Exception {
    if (groqKey != null && !groqKey.trim().isEmpty()) {
      try {
        return callOpenAiCompat("https://api.groq.com/openai/v1/chat/completions", groqKey.trim(), "openai/gpt-oss-120b", systemPrompt, userMessage);
      } catch (Exception ignored) {}
    }
    if (openRouterKey != null && !openRouterKey.trim().isEmpty()) {
      try {
        return callOpenAiCompat("https://openrouter.ai/api/v1/chat/completions", openRouterKey.trim(), "openrouter/free", systemPrompt, userMessage);
      } catch (Exception ignored) {}
    }
    throw new IOException("All fallback providers exhausted.");
  }

  private static String callOpenAiCompat(String endpoint, String apiKey, String model, String sys, String user) throws Exception {
    HttpsURLConnection conn = (HttpsURLConnection) new URL(endpoint).openConnection();
    try {
      conn.setRequestMethod("POST");
      conn.setConnectTimeout(10000);
      conn.setReadTimeout(18000);
      conn.setDoOutput(true);
      conn.setRequestProperty("Content-Type", "application/json");
      conn.setRequestProperty("Authorization", "Bearer " + apiKey);
      JSONArray msgs = new JSONArray()
          .put(new JSONObject().put("role", "system").put("content", sys))
          .put(new JSONObject().put("role", "user").put("content", user));
      JSONObject payload = new JSONObject().put("model", model).put("messages", msgs);
      try (OutputStream out = conn.getOutputStream()) {
        out.write(payload.toString().getBytes(StandardCharsets.UTF_8));
      }
      int status = conn.getResponseCode();
      if (status < 200 || status >= 300) throw new IOException("HTTP " + status);
      try (InputStream in = conn.getInputStream(); ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
        byte[] buf = new byte[4096];
        int n;
        while ((n = in.read(buf)) != -1) bos.write(buf, 0, n);
        JSONObject json = new JSONObject(new String(bos.toByteArray(), StandardCharsets.UTF_8));
        return json.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content");
      }
    } finally {
      conn.disconnect();
    }
  }
}
