package com.myraa.mobile;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.List;

public final class DarkAccessibilityService extends AccessibilityService {
  public static volatile boolean autoSendPending = false;

  @Override
  public void onAccessibilityEvent(AccessibilityEvent event) {
    if (!autoSendPending) return;
    AccessibilityNodeInfo root = getRootInActiveWindow();
    if (root == null) return;
    List<AccessibilityNodeInfo> sendBtns = root.findAccessibilityNodeInfosByViewId("com.whatsapp:id/send");
    if (sendBtns != null && !sendBtns.isEmpty()) {
      for (AccessibilityNodeInfo btn : sendBtns) {
        if (btn.isClickable()) {
          autoSendPending = false;
          btn.performAction(AccessibilityNodeInfo.ACTION_CLICK);
          return;
        }
      }
    }
  }

  @Override
  public void onInterrupt() {}
}
