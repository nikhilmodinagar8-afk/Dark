package com.myraa.mobile;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Environment;

/**
 * DarkMediaAndScreenShareService (DARK v7.0 Omni-Control):
 * 1. Downloads videos/media directly to Downloads/DARK_Vault via Android DownloadManager.
 * 2. Shares any video/link directly to WhatsApp or any target app via Intent.ACTION_SEND + DarkAccessibilityService auto-send.
 * 3. Starts non-root Live Screen Sharing via Android MediaProjectionManager.
 * 4. Reads Clipboard text for instant Hinglish translation & summarization.
 */
public final class DarkMediaAndScreenShareService {
  public static final int SCREEN_SHARE_REQUEST_CODE = 901;
  private final Activity activity;

  public DarkMediaAndScreenShareService(Activity activity) {
    this.activity = activity;
  }

  public long downloadVideoUrl(String videoUrl, String title) {
    DownloadManager dm = (DownloadManager) activity.getSystemService(Context.DOWNLOAD_SERVICE);
    DownloadManager.Request req = new DownloadManager.Request(Uri.parse(videoUrl))
        .setTitle(title != null ? title : "DARK_Video.mp4")
        .setDescription("Downloading via DARK AI...")
        .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
        .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "DARK_Vault/" + (title != null ? title : "video.mp4"));
    return dm.enqueue(req);
  }

  public void shareMediaToWhatsApp(String mediaUrlOrText, String contactPhoneE164) {
    DarkAccessibilityService.autoSendPending = true;
    Intent sendIntent = new Intent(Intent.ACTION_SEND);
    sendIntent.setType("text/plain");
    sendIntent.putExtra(Intent.EXTRA_TEXT, mediaUrlOrText);
    sendIntent.setPackage("com.whatsapp");
    if (contactPhoneE164 != null && !contactPhoneE164.isEmpty()) {
      sendIntent.putExtra("jid", contactPhoneE164 + "@s.whatsapp.net");
    }
    sendIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    activity.startActivity(sendIntent);
  }

  public void requestLiveScreenShare() {
    MediaProjectionManager mpm = (MediaProjectionManager) activity.getSystemService(Context.MEDIA_PROJECTION_SERVICE);
    if (mpm != null) {
      activity.startActivityForResult(mpm.createScreenCaptureIntent(), SCREEN_SHARE_REQUEST_CODE);
    }
  }

  public String readClipboardText() {
    ClipboardManager cm = (ClipboardManager) activity.getSystemService(Context.CLIPBOARD_SERVICE);
    if (cm != null && cm.hasPrimaryClip() && cm.getPrimaryClip().getItemCount() > 0) {
      CharSequence cs = cm.getPrimaryClip().getItemAt(0).getText();
      return cs != null ? cs.toString() : "";
    }
    return "";
  }
}
