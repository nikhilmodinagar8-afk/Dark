# DARK AI — Dark-Purple Nebula UI, Owner Voice + Typing Biometrics & MYRAA Cognitive Core

Yeh project **DARK AI** ka pura Android & Cognitive source code hai:
1. **Dark-Purple & Obsidian Nebula UI (<9 MB RAM — Old Phone Compatible):**
   - Heavy 3D `.pmx` anime model ko hata kar **Dark Purple Swirling Nebula Orb & Glassmorphic Bento UI** lagaya gaya hai jo 2GB/3GB RAM wale purane phones par bhi **60 FPS** par bina lag ke chalta hai.
2. **Owner Voice + Typing Style Biometric Guard (`OwnerBiometricGuard.java`):**
   - **Voiceprint Recognition:** Aapki aawaz ki pitch ($F_0$ Hz), speaking speed, aur cadence se pehchanta hai ki aap bol rahe hain ya koi aur.
   - **Typing Style Biometrics:** Aapke keystroke दबाने ki raftaar (**Dwell Time** & **Flight Time** in ms) aur aapke unique **Hinglish likhne ke style** (*"muzhye"*, *"jessy"*, *"krpyga"*, *"esko"*, *"hnu"*) se turant samajh jata hai ki phone aapke haath mein hai ya kisi stranger ke haath mein!
3. **Full MYRAA Backend Functionality Retained:**
   - `cognition/` (11-stage Event Bus, Situation Model, Attention & Initiative Engine, Goal & Skill Manager, Critic, Structured Memory, RMS Barge-in Voice)
   - `api_hub/` (Public APIs Hub) + **7-Provider Free Multi-API Auto-Fallback Router**
   - `DarkAccessibilityService.java` (Non-Root WhatsApp Auto-Send & Full Screen Control)
